package FoodOrderingSystem;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FoodOrderingSystem {
    private JCheckBox cPizza;
    private JCheckBox cBurger;
    private JCheckBox cFries;
    private JCheckBox cSoftDrinks;
    private JCheckBox cTea;
    private JCheckBox cSundae;
    private JRadioButton rbNone;
    private JRadioButton rb5;
    private JRadioButton rb10;
    private JRadioButton rb15;
    private JButton btnOrder;
    FoodOrderingSystem(){
        JRadioButton[] rbDisc = {rbNone, rb5, rb10, rb15};
        JCheckBox[] cbFood = {cPizza, cBurger, cFries, cSoftDrinks,cTea,cSundae };


        btnOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double sum = 0, total = 0;
                double disc;
                String discType = null;

                for(JCheckBox cb : cbFood){
                    if(cb.isSelected()){
                        if(cb.getText() == "Pizza"){
                            sum += 100;
                        }
                        if(cb.getText() == "Burger"){
                            sum += 80;
                        }
                        if(cb.getText() == "Fries"){
                            sum += 65;
                        }
                        if(cb.getText() == "Soft Drinks"){
                            sum += 5;
                        }
                        if(cb.getText() == "Tea"){
                            sum += 50;
                        }
                        if(cb.getText() == "Sundae"){
                            sum += 40;
                        }
                    }
                }

                for(JRadioButton rb : rbDisc){
                    if(rb.isSelected()){
                        discType = rb.getText();
                    }
                }
                if(discType == "None"){
                    disc = 0 * sum;
                }else if(discType == "5% Off"){
                    disc = 0.05 * sum;
                }else if(discType == "10% Off"){
                    disc = 0.1 * sum;
                }else{
                    disc = 0.15 * sum;
                }
                total = sum - disc;
            }
        });
    }
}
