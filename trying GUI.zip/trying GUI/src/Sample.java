import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Sample extends JFrame{
    private JTextField tfName;
    private JPanel pMain;
    private JButton btnOK;
    private JRadioButton rbMale;
    private JRadioButton rbFemale;
    private JRadioButton rbOthers;
    private JRadioButton rbFirst;
    private JRadioButton rbSecond;
    private JRadioButton rbThird;
    private JRadioButton rbFourth;
    private JTextArea taOutput;
    private JComboBox cbProgram;
    private JCheckBox cbCSS;
    private JCheckBox cbGDSC;
    private JCheckBox cbDOST;
    private JCheckBox cbSSG;
    private JCheckBox cbOthers;
    private JTextField tfOtherOrg;

    Sample(){
        JRadioButton[] rbYear = {rbFirst, rbSecond, rbThird, rbFourth};
        JCheckBox[] cbOrgs = {cbCSS, cbGDSC, cbDOST, cbSSG, cbOthers};

    cbOthers.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if(tfOtherOrg.isVisible()){
                tfOtherOrg.setVisible(false);
            }
            else{
                tfOtherOrg.setVisible(true);
            }
            revalidate();
        }
    });

        btnOK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                taOutput.setText("");
                String name = tfName.getText();
                taOutput.append("Name: " + name + "\n");

                if(rbMale.isSelected()){
                    taOutput.append("Gender: Male\n");
                } else if (rbFemale.isSelected()) {
                    taOutput.append("Gender: Female\n");
                } else if (rbOthers.isSelected()) {
                    taOutput.append("Gender: Others\n");
                }else taOutput.append("Error! No gender!\n");

                for(JRadioButton rb : rbYear){
                    if(rb.isSelected()){
                        taOutput.append("Year Level: " + rb.getText() + "\n");
                    }
                }

                if(cbProgram.getSelectedIndex()==0){
                    JOptionPane.showMessageDialog(null, "Choose a program!");
                    taOutput.setText("");
                }else {
                    taOutput.append("Program: " + (String) cbProgram.getSelectedItem() + "\n");
                }
                int ctr = 0;
                taOutput.append("Organizations: ");
                for(JCheckBox cb : cbOrgs){
                    if(cb.isSelected()){
                        if(ctr==0)
                        {
                            if(cb.getText() != "Others") {
                                taOutput.append(cb.getText());
                                ctr++;
                            }
                        }
                        else{
                            if(cb.getText() != "Others") {
                                taOutput.append(", " + (String)cb.getText() + "\n");
                                ctr++;
                            }
                        }
                    }
                }
                if(rbOthers.isSelected())
                {
                    taOutput.append((String)tfOtherOrg.getText());
                }
                if(ctr == 0){
                    taOutput.append("NONE\n");
                }
            }
        });
    }
    public static void main(String[] args) {
        Sample s = new Sample();
        s.setContentPane(s.pMain);
        s.setSize(800, 800);
        s.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        s.setVisible(true);
    }
}

